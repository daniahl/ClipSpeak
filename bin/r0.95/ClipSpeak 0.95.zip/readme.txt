ClipSpeak, v0.95
Copyright(c) 2008, Daniel Innala Ahlmark
http://www.codeplex.com/clipspeak


What is ClipSpeak
=================
ClipSpeak is a portable, lightweight text-to-speech tool that speaks text copied to the clipboard. It is intended to be as transparent as possible to the user, keeping user interface and interaction to a minimum.
At this moment it simply uses the voice selected in the control panel's speech dialogue, but support is planned to allow voice selection in the program.

How to use it
=============
When you start ClipSpeak it will position itself in the system tray area. Now just select some text and copy it, and ClipSpeak will speak it.
To close ClipSpeak, right-click it's icon in the system tray and select Exit.


Visit the page at Codeplex for more information. There you can discuss ClipSpeak, obtain the latest release, or the source code.
